package com.icesigames.arithgo;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class FragmentOperation extends Fragment {


    private TextView txt1, txt2;
    private TextView txt_resultado;

    private TextView txt_operador;

    private EditText resultadoIngresado;
    private Button botonCalcular;
    private OnFragmentInteractionListener mListener;
    private View view;

    public FragmentOperation() {
        // Required empty public constructor
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
                view = inflater.inflate(R.layout.fragment_operation, container, false);

        txt1 = (TextView) view.findViewById(R.id.txt_valor1);
        txt2 = view.findViewById(R.id.txt_valor2);
        txt_resultado = view.findViewById(R.id.txt_resultado);
        txt_operador = view.findViewById(R.id.txt_operador);
        resultadoIngresado =view.findViewById(R.id.resultado_ingresado);
        botonCalcular = view.findViewById(R.id.button);

        String name=this.getArguments().getString("NAME_KEY").toString();
        int year=this.getArguments().getInt("YEAR_KEY");





        txt_resultado.setText("Resulve el siguiente problema aritmético. \n" + "Por cada operación correcta ganarás +1 punto \n"
                + "Por cada operación errónea perderás un punto. \n" + "¡Buena suerte!");

        String[] opciones = {"+", "-", "x", "/"};
        txt_operador.setText("s");

        txt1.setText("asd");
        txt2.setText( "asd");

        botonCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // calcular(view);

                Log.v(">>", "xddd");
            }
        });


        int yearr=this.getArguments().getInt("YEAR_KEY");

        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);



    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState)
    {
        super.onActivityCreated(savedInstanceState);




    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }












}
