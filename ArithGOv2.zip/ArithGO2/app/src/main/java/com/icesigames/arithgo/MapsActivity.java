package com.icesigames.arithgo;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.maps.android.PolyUtil;

import java.text.DecimalFormat;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, LocationListener {

    private GoogleMap mMap;
    private Marker miUbicacion;
    private Polygon ABuildingArea;
    private Polygon samanArea;
    private Polygon libraryArea;
    private FragmentOperation fragmentOperation;
    private FragmentExchange fragmentExchange;

    private int valor1;
    private int valor2;
    private int valorOpcion;



    @SuppressLint("MissingSuperCall")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
        }, 11);
        //

        String[] opciones = {"Sumar", "Restar", "Multiplicar", "Dividir"};


        fragmentOperation = new FragmentOperation();
        fragmentExchange = new FragmentExchange();

        valor1 = (int) (Math.random() * 100 + 1);
        valor2 = (int) (Math.random() * 100 + 1);
        valorOpcion = (int) (Math.random() * 3);

Bundle bundle =  new Bundle();
bundle.putInt("VALOR1",4 );
    }


    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLng ubicacionMia = new LatLng(3.341778   , -76.530512);
        miUbicacion = mMap.addMarker(new MarkerOptions().position(ubicacionMia).title("Mi ubicación"));
        miUbicacion.setIcon(BitmapDescriptorFactory.fromResource(R.drawable.man));

        //Edificio A ------------------------------------------------------------------------
        //SUPIZ 3.341917 , -76.5306
        //SUPDER 3.3419 , -76.530336
        //INFDER 3.341714 , -76.530606
        //INFIZQ 3.341702 , -76.530357

        ABuildingArea = mMap.addPolygon(new PolygonOptions().add(
                new LatLng(3.342133 , -76.530096),
                new LatLng(3.342112 , -76.529788),
                new LatLng(3.341958 , -76.529802),
                new LatLng(3.341982 , -76.530101)

        ));
        //Trazo amarillo
        ABuildingArea.setStrokeColor(-256 );

        //SAMAN------------------------------------------------------------------------
        //SUPIZ 3.341917 , -76.5306
        //SUPDER 3.3419 , -76.530336
        //INFDER 3.341714 , -76.530606
        //INFIZQ 3.341702 , -76.530357

        samanArea = mMap.addPolygon(new PolygonOptions().add(
                new LatLng(3.341917, -76.5306),
                new LatLng(3.3419, -76.530336),
                new LatLng(3.341702, -76.530357),
                new LatLng(3.341714, -76.530606)

        ));
        //Color verde trazo
        samanArea.setStrokeColor(-16711936 );

        //BIBLIOTECA------------------------------------------------------------------------
        //SUPIZ 3.341917 , -76.5306
        //SUPDER 3.3419 , -76.530336
        //INFDER 3.341714 , -76.530606
        //INFIZQ 3.341702 , -76.530357

        libraryArea = mMap.addPolygon(new PolygonOptions().add(
                new LatLng(3.341952 , -76.530082),
                new LatLng(3.341945 , -76.529789),
                new LatLng(3.341667 , -76.529794),
                new LatLng(3.34167 , -76.530089)

        ));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(ubicacionMia, 15));

        //Pedir que el sensor comience a medir
        LocationManager manager = (LocationManager) getSystemService(LOCATION_SERVICE);
        manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, this);

        boolean isInSaman = PolyUtil.containsLocation(ubicacionMia, samanArea.getPoints(), true);
        if (isInSaman) {

            Toast.makeText(this, "gggg", Toast.LENGTH_SHORT).show();
            setContentView(R.layout.fragment_operation);



            //HACER APARECER TRIVIA ----------------------------------------------------------------------------------
            // icesi.setVisibility(View.VISIBLE);
        } else {
            // icesi.setVisibility(View.GONE);
        }


    }



    @Override
    public void onLocationChanged(Location location) {

        LatLng coord = new LatLng(location.getLatitude(), location.getLongitude());
        miUbicacion.setPosition(coord);
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(coord, 15));



        boolean isInABulding = PolyUtil.containsLocation(coord, ABuildingArea.getPoints(), true);
        if (isInABulding) {

            setContentView(R.layout.fragment_operation);
            //HACER APARECER TRIVIA----------------------------------------------------------------------------------
            // icesi.setVisibility(View.VISIBLE);
        } else {
            // icesi.setVisibility(View.GONE);
        }


        boolean isInSaman = PolyUtil.containsLocation(coord, samanArea.getPoints(), true);
        if (isInSaman) {

            Toast.makeText(this, "gggg", Toast.LENGTH_SHORT).show();
            setContentView(R.layout.fragment_operation);


            //HACER APARECER TRIVIA ----------------------------------------------------------------------------------
             // icesi.setVisibility(View.VISIBLE);
        } else {
            // icesi.setVisibility(View.GONE);
        }


        boolean isInBiblioteca = PolyUtil.containsLocation(coord, libraryArea.getPoints(), true);
        if (isInBiblioteca) {

            setContentView(R.layout.fragment_exchange);

            //HACER APARECER TRIVIA ----------------------------------------------------------------------------------
            // icesi.setVisibility(View.VISIBLE);
        } else {
            // icesi.setVisibility(View.GONE);
        }


    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }

    public double darDistancia(Marker unPunto, Marker otroPunto) {

        double distancia = 0.0;
        if (unPunto != null && otroPunto != null) {
            double latDiff = unPunto.getPosition().latitude - otroPunto.getPosition().latitude;
            double longDiff = unPunto.getPosition().longitude - otroPunto.getPosition().longitude;

            distancia = Math.sqrt(Math.pow(latDiff, 2) + Math.pow(longDiff, 2));

            distancia = distancia = distancia * 111.12 * 1000;

        }

        return distancia;
    }

    public void onMapLongClick(LatLng latLng) {


    }


    @Override
    public void onResume() {

        super.onResume();
    }

    @Override
    public void onPause() {



        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }


    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }


    public void calcular(View v) {


        Toast.makeText(getContext(), "ghhhh", Toast.LENGTH_SHORT).show();
        String[] opciones = {"Sumar", "Restar", "Multiplicar", "Dividir"};


        String seleccion = opciones[valorOpcion];

        int resultadoEntero = Integer.parseInt(resultadoIngresado.getText().toString());
        double resultadoDecimal = Double.parseDouble(resultadoIngresado.getText().toString());


        if (seleccion.equals("Sumar")) {

            if (resultadoEntero == (valor1 + valor2)) {
                txt_resultado.setText("El resultado es correcto. Ganas +1 punto.");

                //ACCION DE GANAR O PERDER PUNTOS----------------------------------------------------------------

            } else {

                //ACCION DE GANAR O PERDER PUNTOS----------------------------------------------------------------
                txt_resultado.setText("El resultado es incorrecto. Pierdes -1 punto.");
            }


        } else if (seleccion.equals("Restar")) {
            if (resultadoEntero == (valor1 - valor2)) {

                //ACCION DE GANAR O PERDER PUNTOS----------------------------------------------------------------
                txt_resultado.setText("El resultado es correcto. Ganas +1 punto.");

            } else {

                //ACCION DE GANAR O PERDER PUNTOS----------------------------------------------------------------
                txt_resultado.setText("El resultado es incorrecto. Pierdes -1 punto.");
            }


        } else if (seleccion.equals("Multiplicar")) {

            if (resultadoEntero == (valor1 * valor2)) {
                txt_resultado.setText("El resultado es correcto. Ganas +1 punto.");

                //ACCION DE GANAR O PERDER PUNTOS----------------------------------------------------------------

            } else {

                //ACCION DE GANAR O PERDER PUNTOS----------------------------------------------------------------
                txt_resultado.setText("El resultado es incorrecto. Pierdes -1 punto.");
            }

        } else if (seleccion.equals("Dividir")) {
            if (valor2 == 0) {
                txt_resultado.setText("No se puede dividir entre cero");


            } else {
                if (resultadoIngresado.getText().toString().contains(",")) {
                    txt_resultado.setText("Escriba el decimal del resultado con punto('.') en vez de coma (',').");
                } else {

                    double v1 = valor1 + 0.00;
                    double v2 = valor2 + 0.00;

                    double division = v1 / v2;

                    if (resultadoDecimal == (division)) {
                        txt_resultado.setText("El resultado es correcto. Ganas +1 punto.");

                        //ACCION DE GANAR O PERDER PUNTOS----------------------------------------------------------------

                    } else {

                        //ACCION DE GANAR O PERDER PUNTOS----------------------------------------------------------------
                        txt_resultado.setText("El resultado es incorrecto. Pierdes -1 punto.");
                    }
                }


            }

        }


    }

}
