package com.example.app_radiobutton;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText txt1, txt2;
    private TextView tv;
    private RadioButton rbSumar, rbRestar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt1 = findViewById(R.id.txt_valor1);
        txt2 = findViewById(R.id.txt_valor2);
        tv = findViewById(R.id.txt_resultado);
        rbSumar = findViewById(R.id.rb_sumar);
        rbRestar = findViewById(R.id.rb_restar);

    }

    public void calcular(View v) {
        int valor1 = Integer.parseInt(txt1.getText().toString());
        int valor2 = Integer.parseInt(txt2.getText().toString());

        if (rbSumar.isChecked() == true) {
            tv.setText("" + (valor1 + valor2));

        } else if (rbRestar.isChecked() == true) {
            tv.setText("" + (valor1 - valor2));
            Toast.makeText(MainActivity.this, "Has restado!", Toast.LENGTH_SHORT).show();



        }
    }
}
