package com.example.listaslibreta;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class ContactAdapter extends BaseAdapter {

    private ArrayList<Contact> contacts;

    public ContactAdapter(){
        contacts = new ArrayList<>();

    }



    @Override
    public int getCount() {
        return contacts.size();
    }

    @Override
    public Object getItem(int position) {
        return contacts.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    //Se encarga de un objeto visible a la vez
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

       LayoutInflater inflater = (LayoutInflater) parent.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
       View view = inflater.inflate(R.layout.row, null);


        TextView rowName = view.findViewById(R.id.fecha_hoy);
        TextView rowCall = view.findViewById(R.id.row_like);
        TextView rowDelete = view.findViewById(R.id.row_views);

        final Contact data = contacts.get(position);


        //rowCall TAREA: ACTION_CALL --------------------------------------------------------------------------------------------------

        rowDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                contacts.remove(data);
                notifyDataSetChanged();
            }
        });

        rowName.setText(data.getFechaHoy());
        rowName.setText(data.getTelefono());




        return view;
    }

    public void addContact(Contact c )
    {
        contacts.add(c);
        notifyDataSetChanged();

    }

}
