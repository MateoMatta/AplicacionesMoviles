package com.example.listaslibreta;

public class Contact {

    private String fechaHoy;
    private String telefono;

    public Contact(){}

    public Contact(String fechaHoy, String telefono) {

        this.fechaHoy = "xd";
        this.telefono = telefono;
    }

    public String getFechaHoy() {
        return fechaHoy;
    }

    public void setFechaHoy(String fechaHoy) {
        this.fechaHoy = fechaHoy;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}
